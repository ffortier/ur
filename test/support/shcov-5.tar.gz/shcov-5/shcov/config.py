PROGRAM_NAME = "shcov"
PROGRAM_VERSION = 5

PROGRAM_URL = "http://shcov.googlecode.com"
