#!/bin/sh

function main() {
    echo "Hejsan hoppsan"
}

echo "Vobb second"
main
