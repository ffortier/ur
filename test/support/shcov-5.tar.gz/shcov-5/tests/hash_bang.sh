#!/usr/bin/python ../scripts/shcov

echo Rad 1
echo Rad 2
